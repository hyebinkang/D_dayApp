package com.guru22.d_daylist;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.guru22.d_daylist.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;


public class AddActivity extends AppCompatActivity {

    FirebaseAuth auth;
    private FirebaseDatabase database;
    private DatabaseReference myref1;
    private DatePickerDialog.OnDateSetListener callbackMethod;
    int selectYear, selectMonth, selectDay;
    private Button date;

    // 현재 날짜를 알기 위해 사용
    private Calendar mCalendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // uid 데이터 가져오기
        Intent intent = getIntent();
        final String uid = getIntent().getStringExtra("uid");

        final TextView title = (TextView) findViewById(R.id.edit_todo_name);
        date = (Button) findViewById(R.id.edit_date_button);
        final TextView memo = (TextView) findViewById(R.id.edit_memo);

        // 현재 날짜를 알기 위해 사용
        mCalendar = new GregorianCalendar();

        // 날짜 클릭 시
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDate();
            }
        });
        this.InitializeListener();

        //데이터베이스 연동
        database = FirebaseDatabase.getInstance();

        // 사용자 구분
        myref1 = database.getReference("user").child(uid);

        //취소 버튼
        Button cancel_button = (Button) findViewById(R.id.cancel_button);
        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),
                        MainActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                finish();
            }
        });

        //저장 버튼
        Button save_button = (Button) findViewById(R.id.save_button);
        save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String title1 = title.getText().toString();
                String memo1 = memo.getText().toString();

                Intent intent = new Intent(getApplicationContext(),
                        MainActivity.class);
                Toast.makeText(AddActivity.this, "저장되었습니다.", Toast.LENGTH_SHORT).show();

                intent.putExtra("title", title1);
                intent.putExtra("memo", memo1);
                intent.putExtra("year", selectYear);
                intent.putExtra("month", selectMonth);
                intent.putExtra("day", selectDay);

                //hashmap 만들기(Realtime Database에 등록)
                HashMap result = new HashMap<>();
                result.put("title", title1);
                result.put("memo", memo1);
                result.put("year", selectYear);
                result.put("month", selectMonth);
                result.put("day", selectDay);

                myref1.push().setValue(result);

                startActivity(intent);
                overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                finish();
            }
//            }
        });

    }

    //날짜 선택 후 변경되는 텍스트
    public void InitializeListener() {
        callbackMethod = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int a_year, int a_monthOfYear, int a_dayOfMonth) {
                selectYear = a_year;
                selectMonth = a_monthOfYear;
                selectDay = a_dayOfMonth;
                date.setText(Integer.toString(selectYear) + "년 " + Integer.toString(selectMonth + 1) + "월 " + Integer.toString(selectDay) + "일");
            }
        };
    }

    //날짜 클릭 시 처음 보여지는 캘린더 화면
    public void showDate() {
        DatePickerDialog dialog = new DatePickerDialog(this, callbackMethod,
                mCalendar.get(Calendar.YEAR), mCalendar.get(Calendar.MONTH),
                mCalendar.get(Calendar.DAY_OF_MONTH));
        dialog.getDatePicker().setMinDate(mCalendar.getInstance().getTimeInMillis());
        dialog.show();
    }

    //안드로이드 뒤로가기
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(getApplicationContext(),
                MainActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        finish();
    }
}
