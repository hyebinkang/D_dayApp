package com.guru22.d_daylist

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Process
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnLongClickListener
import android.view.ViewGroup
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.IdpResponse
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.FirebaseError
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.guru22.d_daylist.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.system.exitProcess


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MyViewModel by viewModels()

    var auth: FirebaseAuth? = null
    private var database: FirebaseDatabase? = null
    private var myref: DatabaseReference? = null
    private var myref1: DatabaseReference? = null

    private var layoutManager: RecyclerView.LayoutManager? = null
    internal var items: List<Goal> = ArrayList()
    internal lateinit var adapter: FirebaseRecyclerAdapter<Goal, GoalViewHolder>

    private val RC_SIGN_IN = 1001
    private lateinit var main_activity: Activity


    // Millisecond 형태의 하루(24 시간)
    private val ONE_DAY = 24 * 60 * 60 * 1000

    companion object {
        var cal: Int? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // 로그인 안된 경우
        if (FirebaseAuth.getInstance().currentUser == null) {
            logIn()
        } else {
            //onResume()
            var user = FirebaseAuth.getInstance().currentUser!!
            //Log.d("uid", "${user.uid}")
            var uidString = user.uid.toString()

            // uid로 사용자 구분
            val myref = FirebaseDatabase.getInstance().getReference("user").child(uidString)

            // 로그아웃 버튼 클릭 시 로그아웃 앱 종료
            val logout_button = findViewById<Button>(R.id.logout_button) as Button
            logout_button.setOnClickListener {
                logOut()
            }

            // '?' 버튼 클릭 시 설명 대화상자
            val instruction_button = findViewById<ImageView>(R.id.instruction) as ImageView
            instruction_button.setOnClickListener {
                val builder =
                    AlertDialog.Builder(this@MainActivity)
                builder.setTitle("D-day 사용법")
                builder.setMessage("""
                    | + 버튼을 눌러 D-day를 추가하세요.
                    |
                    | D-day를 길게 눌러 삭제하세요""".trimMargin())
                builder.setIcon(R.drawable.ic_baseline_contact_support_25)
                builder.setPositiveButton("확인", null)
                builder.show()
            }

            // '+'버튼 클릭 시 액티비티 전환
            val add_button =
                findViewById<ImageView>(R.id.add_button) as ImageView
            add_button.setOnClickListener {
                val intent = Intent(
                    applicationContext,
                    AddActivity::class.java
                )
                // uid 전달
                intent.putExtra("uid", uidString)
                startActivity(intent)
                finish()
            }


            binding.recyclerview.apply {
                layoutManager = LinearLayoutManager(this@MainActivity)
            }

            //리스트 가져오기(파이어베이스)
            binding.recyclerview.setHasFixedSize(true) // 리사이클러뷰 기존성능 강화
            layoutManager = LinearLayoutManager(this)
            binding.recyclerview.setLayoutManager(layoutManager)

            val options = FirebaseRecyclerOptions.Builder<Goal>()
                .setQuery(
                    myref,
                    Goal::class.java
                )
                .build()


            adapter = object : FirebaseRecyclerAdapter<Goal, GoalViewHolder>(options) {
                override fun onCreateViewHolder(
                    parent: ViewGroup,
                    viewType: Int
                ): GoalViewHolder {
                    val view: View = LayoutInflater.from(parent.context)
                        .inflate(R.layout.item, parent, false)
                    return GoalViewHolder(view)
                }

                override fun onBindViewHolder(
                    holder: GoalViewHolder,
                    position: Int,
                    model: Goal
                ) {
                    holder.goal_text.setText(model.title)
                    val dday = getDday(model.year, model.month, model.day)

                    if (dday == "D-Day") {
                        holder.goal_dday.setText(dday)
                        holder.goal_dday.setTextColor(Color.RED)
                    } else {
                        holder.goal_dday.setText(dday)
                    }

                    //롱클릭 시 삭제 구현
                    holder.parentLayout.setOnLongClickListener(OnLongClickListener {
                        val alt_bld =
                            AlertDialog.Builder(this@MainActivity)
                        alt_bld.setTitle("삭제하시겠습니까?").setCancelable(
                            false
                        ).setNeutralButton(
                            "확인"
                        ) { dialogInterface, id ->
                            Log.v("삭제", "완료")
                            val currentTitle: String? = model.title
//                            val myref1 =
//                                FirebaseDatabase.getInstance().getReference("add")
                            val myref1 =
                                FirebaseDatabase.getInstance().getReference("user").child(uidString)
                            val firebaseSearchQuery =
                                myref1.orderByChild("title").equalTo(currentTitle)
                            firebaseSearchQuery.addListenerForSingleValueEvent(object :
                                ValueEventListener {
                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                    if (dataSnapshot.exists()) {
                                        for (appleSnapshot in dataSnapshot.children) {
                                            appleSnapshot.ref.removeValue()
                                        }
                                    }
                                }

                                override fun onCancelled(databaseError: DatabaseError) {}
                                fun onCancelled(firebaseError: FirebaseError?) {}
                            })
                            adapter!!.notifyDataSetChanged()
                            Toast.makeText(
                                this@MainActivity,
                                "삭제되었습니다.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }.setNegativeButton(
                            "취소   "
                        ) { dialog, id ->
                            Log.v("삭제", "취소")
                            // 취소 클릭. dialog 닫기.
                            dialog.cancel()
                        }
                        val alert = alt_bld.create()
                        alert.show()
                        true
                    })


                    //리스트 클릭 시 화면전환
                    holder.parentLayout.setOnClickListener(object :
                        View.OnClickListener {
                        override fun onClick(v: View) {
                            val intent =
                                Intent(v.context, AddDetailsActivity::class.java)
                            intent.putExtra("title", model.title)
                            intent.putExtra("year", model.year)
                            intent.putExtra("month", model.month)
                            intent.putExtra("day", model.day)
                            intent.putExtra("memo", model.memo)
                            // uid 전달
                            intent.putExtra("uid", uidString)
                            v.context.startActivity(intent)
                            overridePendingTransition(R.anim.fadein, R.anim.fadeout)
                            finish()
                        }

                        private fun overridePendingTransition(
                            fadein: Int,
                            fadeout: Int
                        ) {
                        }
                    })
                }
            }
            adapter.startListening()
            binding.recyclerview.setAdapter(adapter)

            //화면 새로고침
            binding.refreshlayout.setOnRefreshListener {
                binding.recyclerview.removeAllViews();
                binding.recyclerview.setAdapter(adapter);
                binding.refreshlayout.isRefreshing = false
            }
        }
    }

    // 로그인 결과 전달
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RC_SIGN_IN) {
            val response = IdpResponse.fromResultIntent(data)

            if (resultCode == Activity.RESULT_OK) {
                val user = FirebaseAuth.getInstance().currentUser

                // 화면 갱신
                val intent = intent
                finish()
                startActivity(intent)

            } else {    // 로그인 실패
                finishAffinity()
                exitProcess(0)
                Process.killProcess(Process.myPid())
            }
        }
    }

    // 로그인
    fun logIn() {
        val providers = arrayListOf(AuthUI.IdpConfig.EmailBuilder().build())

        startActivityForResult(
            AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(providers)
                .build(),
            RC_SIGN_IN
        )
    }

    // 로그아웃
    fun logOut() {
        AuthUI.getInstance()
            .signOut(this)
            .addOnCompleteListener {
                logIn()
            }
    }

    data class Goal(
        var title: String? = null, // 목표
        var year: Int = Calendar.getInstance().get(Calendar.YEAR),        // 년도
        var month: Int = Calendar.getInstance().get(Calendar.MONTH),      // 월
        var day: Int = Calendar.getInstance().get(Calendar.DAY_OF_MONTH), // 일
        var memo: String? = null // 메모 내용, 디폴트 값은 null
    )


    class GoalAdapter(
        arrayList: ArrayList<Goal>,
        context: Context
    ) :

        RecyclerView.Adapter<GoalViewHolder>() {
        var mContext: Context
        var arrayList: ArrayList<Goal>
        var auth: FirebaseAuth? = null
        private var itemClick: ItemClick? = null

        interface ItemClick {
            fun onClick(view: View?, position: Int)
        }

        //아이템 클릭시 실행 함수 등록 함수
        fun setItemClick(itemClick: ItemClick?) {
            this.itemClick = itemClick
        }

        interface OnItemClickListener {
            fun onItemClick(view: View?, position: Int)
            fun onItemLongClick(view: View?, position: Int)
        }

        private val mListener: OnItemClickListener? = null
        override fun getItemCount(): Int {
            return arrayList.size
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GoalViewHolder {
            val v: View = LayoutInflater.from(parent.context)
                .inflate(R.layout.item, parent, false)
            return GoalViewHolder(v)
        }

        private fun getDday(year: Int, month: Int, day: Int): String {
            val dday = Calendar.getInstance()
            dday.set(year, month, day)
            val today = Calendar.getInstance()
            val mToday = today.timeInMillis / 86400000
            val mSelectday = dday.timeInMillis / 86400000
            var result = (mSelectday - mToday)
            val d_Day: String
            if (result > 0) {
                d_Day = "D-%d"
            } else if (result.toInt() == 0) {
                d_Day = "D-Day"
            } else {
                result *= -1
                d_Day = "D+%d"
            }

            var Count: String = String.format(d_Day, result)
            return Count
        }

        override fun onBindViewHolder(holder: GoalViewHolder, position: Int) {
            val goal: Goal = arrayList[position]
            holder.goal_text.setText(arrayList[position].title)

            val dday = getDday(
                arrayList[position].year,
                arrayList[position].month,
                arrayList[position].day
            )

            if (dday == "D-Day") {
                holder.goal_dday.setText(dday)
                holder.goal_dday.setTextColor(Color.RED)
            } else {
                holder.goal_dday.setText(dday)
            }

            holder.parentLayout.setOnClickListener(object : View.OnClickListener {
                override fun onClick(v: View) {
                    val intent = Intent(v.context, AddDetailsActivity::class.java)
                    intent.putExtra("title", arrayList[position].title)
                    intent.putExtra("memo", arrayList[position].memo)
                    intent.putExtra("year", arrayList[position].year)
                    intent.putExtra("month", arrayList[position].month)
                    intent.putExtra("day", arrayList[position].day)

                    v.context.startActivity(intent)
                    overridePendingTransition(R.anim.fadein, R.anim.fadeout)
                    (v.context as Activity).finish()
                }

                private fun overridePendingTransition(fadein: Int, fadeout: Int) {}
            })
        }

        companion object {
            private const val TAG = "GoalAdapter"
        }

        init {
            this.arrayList = arrayList
            mContext = context
        }
    }

    //View Holder Class
    class GoalViewHolder(itemView: View) : ViewHolder(itemView) {
        var goal_text: TextView
        var goal_dday: TextView
        var parentLayout: LinearLayout

        //    public LinearLayout parentLayout;
        init {
            goal_text = itemView.findViewById<View>(R.id.todo_name) as TextView
            goal_dday = itemView.findViewById<View>(R.id.d_day) as TextView
            parentLayout = itemView.findViewById(R.id.linear1)
        }
    }

    //D-day 계산
    fun getDday(year: Int, month: Int, day: Int): String {
        val dday = Calendar.getInstance()
        dday.set(year, month, day)
        val today = Calendar.getInstance()
        val mToday = today.timeInMillis / ONE_DAY
        val mSelectday = dday.timeInMillis / ONE_DAY
        var result = (mSelectday - mToday)
        val d_Day: String
        if (result > 0) {

            d_Day = "D-%d"
        } else if (result.toInt() == 0) {

            d_Day = "D-Day"
        } else {

            result *= -1
            d_Day = "D+%d"
        }

        var Count: String = String.format(d_Day, result)

        return Count
    }

    class MyViewModel : ViewModel() {
        val data = arrayListOf<Goal>()

        fun addGoal(goal: Goal) {
            data.add(goal)
        }

        fun deleteGoal(goal: Goal) {
            data.remove(goal)
        }
    }
}




